# Service Account Management - How to Add or Update Service Accounts

This module manages the creation of Google Cloud service accounts and their IAM bindings using centralized configuration in `locals.tf`.

---

## How to Add a New Service Account

### 1. Add Service Account Properties

Edit `locals.tf` and add a new entry to the `service_account_properties` list:

```hcl
service_account_properties = [
  # ...existing accounts...
  {
    account_id   = "my-new-sa"
    purpose      = "Describe the purpose of this service account"
    display_name = "My New Service Account"
  }
  # ...existing accounts...
]
```

---

### 2. Add Workload Identity or Service Account User Bindings (if needed)

If your service account needs special IAM bindings, add an entry to the relevant locals:

#### For Workload Identity Bindings

Add to `wi_bindings`:

```hcl
wi_bindings = [
  # ...existing bindings...
  {
    sa_key = "my-new-sa"
    member = "serviceAccount:${local.palace-gcp-1.project_id}.svc.id.goog[namespace/wi-my-new-sa]"
  }
  # ...existing bindings...
]
```

#### For Service Account User Bindings

Add to `sa_user_bindings`:

```hcl
sa_user_bindings = [
  # ...existing bindings...
  {
    sa_key = "my-new-sa"
    member = "serviceAccount:${google_service_account.sa[\"my-new-sa\"].email}"
  }
  # ...existing bindings...
]
```

---

### 3. Apply Terraform

Run `terraform plan` and `terraform apply` to create/update service accounts and IAM bindings.

---

## Notes

- All service account definitions and IAM bindings are managed in `locals.tf`.
- The main Terraform code (`main.tf`) loops over these lists and maps to allocate resources.
- Only add IAM bindings for service accounts that require them.
- Use the correct `sa_key` (the `account_id` from your service account) in the bindings.

---

## Example

To add a new service account with Workload Identity binding:

1. Add to `service_account_properties`.
2. Add to `wi_bindings` if Workload Identity is needed.
3. Add to `sa_user_bindings` if Service Account User role is needed.

---

Refer to existing entries in `locals.tf` for examples.
