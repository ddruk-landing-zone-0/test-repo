# How to Add a New GCS Bucket Configuration

All GCS bucket definitions and access control are managed centrally in `locals.tf`. To add a new bucket, follow these steps:

---

## 1. Add Service Accounts (if needed)
If your bucket requires new service accounts, add them to the `service_accounts` map:
```hcl
service_accounts = {
  # ...existing code...
  my_service_sa = "my-service-sa@project.iam.gserviceaccount.com"
  # ...existing code...
}
```

---

## 2. Add Groups (if needed)
If you need new groups for access, add them to the `groups` map:
```hcl
groups = {
  # ...existing code...
  my_group = "group:my-group@db.com"
  # ...existing code...
}
```

---

## 3. Add Encryption Keys (if needed)
If your bucket uses a different encryption key, add it to the `encryption_keys` map:
```hcl
encryption_keys = {
  # ...existing code...
  my_key = "projects/xxx/locations/yyy/keyRings/zzz/cryptoKeys/abc"
  # ...existing code...
}
```

---

## 4. Add/Override Defaults (optional)
If you want to change the default values for all buckets, update the `defaults` map:
```hcl
defaults = {
  # ...existing code...
  environment = "dev"
  force_destroy = false
  # ...existing code...
}
```

---

## 5. Add a New Bucket Configuration
Add a new object to the `gcs_buckets` list. You can override any default by specifying it in the object:
```hcl
gcs_buckets = [
  # ...existing buckets...
  {
    name        = "my-new-bucket"
    nar_id      = var.nar_id
    app_name    = local.defaults.app_name
    project_id  = local.defaults.project_id
    object_creators = [
      "serviceAccount:${local.service_accounts.my_service_sa}"
    ]
    object_viewers = [
      "serviceAccount:${local.service_accounts.my_service_sa}"
    ]
    object_admins = [
      "serviceAccount:${local.service_accounts.my_service_sa}",
      local.groups.infra,
      local.groups.app_dev
    ]
    encryption_key_name = local.encryption_keys.default
    location            = local.defaults.location
    environment         = local.defaults.environment
    force_destroy       = local.defaults.force_destroy
  }
  # ...existing buckets...
]
```

---

## 6. Use `try()` in main.tf for Defaults
No changes are needed in `main.tf` for new buckets. The module automatically uses defaults for any missing values.

---

## 7. Apply Terraform
Run `terraform plan` and `terraform apply` to create/update your GCS buckets.

---

## Summary

- **All configuration is in `locals.tf`.**
- **Add new service accounts, groups, or keys to their respective maps if needed.**
- **Add a new object to `gcs_buckets` for each new bucket.**
- **No changes needed in `main.tf`.**
- **Defaults are handled automatically.**

Refer to existing entries in `locals.tf` for examples.