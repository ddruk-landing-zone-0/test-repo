# IAM Refactored Terraform Protocols

This folder contains the refactored IAM Terraform configuration for GCP, organized for modularity and maintainability. All resource and module requisitions are defined via locals in the locals files. **Users should only add or modify the locals files** to introduce new IAM bindings, roles, service accounts, or other requisitions.

---

## How to Add or Modify Requisitions

**All changes must be made in the appropriate `locals.tf` or `locals_pubsub.tf` file.**  
Do **not** edit the main Terraform files directly.

---

## 1. Project/Service Account/Secret Manager IAM Bindings (`main.tf`)

Below are the main resource/module types and the locals you must update for each:

### a. `member_iam` modules

```hcl
module "member_iam" {
  for_each = { for m in local.member_iam_modules : m.name => m }
  source                  = "terraform-google-modules/iam/google//modules/member_iam"
  project_id              = local.palace-gcp-1.project_id
  service_account_address = each.value.sa_email
  prefix                  = each.value.prefix
  project_roles           = each.value.project_roles
}
```

- **Add/modify**: Add a new object to the `member_iam_modules` list in `locals.tf`, referencing service accounts and roles from the mappings.

---

### b. `projects_iam` modules

```hcl
module "projects_iam" {
  for_each = { for m in local.projects_iam_modules : m.name => m }
  source   = "terraform-google-modules/iam/google//modules/projects_iam"
  projects = each.value.projects
  bindings = each.value.bindings
}
```

- **Add/modify**: Add a new object to the `projects_iam_modules` list in `locals.tf`, referencing roles and group members from the mappings.

---

### c. `secret_manager_iam` modules

```hcl
module "secret_manager_iam" {
  for_each = { for m in local.secret_manager_iam_modules : m.name => m }
  source   = "terraform-google-modules/iam/google//modules/secret_manager_iam"
  project  = each.value.project
  secrets  = each.value.secrets
  bindings = each.value.bindings
}
```

- **Add/modify**: Add a new object to the `secret_manager_iam_modules` list in `locals.tf`, referencing service accounts and roles from the mappings.

---

### d. `google_service_account_iam_member` resources

```hcl
resource "google_service_account_iam_member" "member" {
  for_each           = { for m in local.service_account_iam_members : m.name => m }
  service_account_id = each.value.service_account_id
  role               = each.value.role
  member             = each.value.member
}
```

- **Add/modify**: Add a new object to the `service_account_iam_members` list in `locals.tf`, referencing service accounts and roles from the mappings.

---

### e. `google_service_account_iam_binding` resources

```hcl
resource "google_service_account_iam_binding" "binding" {
  for_each           = { for m in local.service_account_iam_bindings : m.name => m }
  service_account_id = each.value.service_account_id
  role               = each.value.role
  members            = each.value.members
}
```

- **Add/modify**: Add a new object to the `service_account_iam_bindings` list in `locals.tf`, referencing service accounts, roles, and member lists from the mappings.
- If you need to reuse a set of members, add them to the `service_account_binding_members` mapping and reference by key.

---

## 2. Pub/Sub IAM Bindings (`main_pubsub.tf`)

Below are the main resource types and the locals you must update for each:

### a. `google_pubsub_topic_iam_member` resources

```hcl
resource "google_pubsub_topic_iam_member" "topic_iam_bindings" {
  for_each = {
    for binding in local.pubsub_topic_iam_bindings :
    "${binding.name}" => binding
  }
  project = local.palace-gcp-1.project_id
  topic   = each.value.topic
  role    = each.value.role
  member  = "serviceAccount:${each.value.member_email}"
}
```

- **Add/modify**: Add a new object to the `pubsub_topic_iam_bindings` list in `locals_pubsub.tf`, referencing topics, roles, and service accounts from the mappings.

---

### b. `google_pubsub_subscription_iam_member` resources

```hcl
resource "google_pubsub_subscription_iam_member" "subscription_iam_bindings" {
  for_each = {
    for binding in local.pubsub_subscription_iam_bindings :
    "${binding.name}" => binding
  }
  project      = local.palace-gcp-1.project_id
  subscription = each.value.subscription
  role         = each.value.role
  member       = "serviceAccount:${each.value.member_email}"
}
```

- **Add/modify**: Add a new object to the `pubsub_subscription_iam_bindings` list in `locals_pubsub.tf`, referencing subscriptions, roles, and service accounts from the mappings.

---

### c. `google_project_iam_binding` resources

```hcl
resource "google_project_iam_binding" "project_iam_bindings" {
  for_each = {
    for binding in local.project_iam_bindings :
    "${binding.name}" => binding
  }
  project = local.palace-gcp-1.project_id
  role    = each.value.role
  members = each.value.members
}
```

- **Add/modify**: Add a new object to the `project_iam_bindings` list in `locals_pubsub.tf`, referencing roles and members from the mappings.

---

### d. `google_service_account_iam_member` resources

```hcl
resource "google_service_account_iam_member" "service_account_iam_bindings" {
  for_each = {
    for binding in local.service_account_iam_bindings :
    binding.name => binding
  }
  service_account_id = "projects/${local.palace-gcp-1.project_id}/serviceAccounts/${local.pubsub_service_accounts[each.value.service_account_key]}"
  role               = each.value.role
  member             = "serviceAccount:${each.value.member_email}"
}
```

- **Add/modify**: Add a new object to the `service_account_iam_bindings` list in `locals_pubsub.tf`, referencing service accounts and roles from the mappings.

---

## Protocols for All Changes

- **Always reuse** service accounts, roles, and member emails from the mappings at the top of the locals files.
- **Never hardcode** emails, roles, or group names in the resource/module groupings—reference the mapping keys.
- **If a new service account, role, or group is needed**, add it to the appropriate mapping first, then reference it in your configuration.
- **Test your changes** by running `terraform plan` to ensure the new or modified requisition is picked up by the main files.

---

## Example: Adding a New Pub/Sub Topic IAM Binding

1. Add the new topic to `pubsub_topics` in `locals_pubsub.tf`.
2. Add the new service account to `pubsub_service_accounts` if needed.
3. Add a new object to `pubsub_topic_iam_bindings` referencing the new topic and service account.

---

## Example: Adding a New Service Account IAM Binding

1. Add the new service account to `service_accounts` in `locals.tf`.
2. Add a new member list to `service_account_binding_members` if needed.
3. Add a new object to `service_account_iam_bindings` referencing the service account, role, and member list.

---

## Summary

- **Only edit the locals files** (`locals.tf`, `locals_pubsub.tf`).
- **Reuse mappings** for all service accounts, roles, and members.
- **Add new requisitions** by extending the appropriate locals list or mapping.
- **Do not edit** `main.tf` or `main_pubsub.tf` directly.

This ensures all IAM and Pub/Sub requisitions are managed in a consistent, DRY, and maintainable way.

