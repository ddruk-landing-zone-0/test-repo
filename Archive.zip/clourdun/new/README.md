# Cloud Run Service Management - How to Add a New Service

This project uses a centralized `locals.tf` to manage all Cloud Run service definitions, configuration, and IAM bindings. The `main.tf` loops over these definitions to deploy and configure services and their IAM permissions.

## Steps to Add a New Cloud Run Service

### 1. Add Service-Specific Settings (if needed)
If your service has unique tags, versions, or other global settings, add a new block at the top of `locals.tf` (e.g., `my_service_dev = { ... }`).

---

### 2. Add the Container Image
Add an entry to the `images` map in `locals.tf`:
```hcl
images = {
  # ...existing code...
  my_service = "gcr.io/my-project/my-service:tag"
  # ...existing code...
}
```

---

### 3. Add Service Account(s)
Add any required service accounts to the `service_accounts` map:
```hcl
service_accounts = {
  # ...existing code...
  my_service_sa = "my-service-sa@project.iam.gserviceaccount.com"
  # ...existing code...
}
```

---

### 4. Add VPC Connector (if needed)
Add to the `vpc_connectors` map if your service needs a specific connector:
```hcl
vpc_connectors = {
  # ...existing code...
  my_service = local.vpc_connector
  # ...existing code...
}
```

---

### 5. Add Encryption Key (if needed)
Add to the `encryption_keys` map if your service uses a specific key:
```hcl
encryption_keys = {
  # ...existing code...
  my_service = local.encryption_key
  # ...existing code...
}
```

---

### 6. Add Environment Variables
Add an entry to the `envs` map for your service:
```hcl
envs = {
  # ...existing code...
  my_service = {
    ENV_VAR_1 = { value = "foo" }
    ENV_VAR_2 = { secret_key_ref = { name = "SECRET_NAME", version = "latest" } }
    # ...
  }
  # ...existing code...
}
```

---

### 7. Add Service Definition to `cloudrun_services`
Add a block to the `cloudrun_services` map with all required and optional overrides:
```hcl
cloudrun_services = {
  # ...existing code...
  my_service = {
    name                  = "my-service"
    containers            = [
      {
        name      = "my-service"
        image     = local.images.my_service
        resources = {
          limits = {
            memory = "512Mi"
            cpu    = "1"
          }
        }
        ports = local.defaults.ports
        env   = [for k, v in local.envs.my_service : merge({ name = k }, v)]
      }
    ]
    service_account_email     = local.service_accounts.my_service_sa
    vpc_connector             = local.vpc_connectors.my_service
    encryption_key            = local.encryption_keys.my_service
    # ...other overrides as needed...
    invoker_service_accounts = [
      "serviceAccount:${local.service_accounts.operations_sa}",
      # Add any other invoker accounts as needed
    ]
  }
  # ...existing code...
}
```

---

### 8. Add IAM Invoker Accounts (if needed)
If your service needs specific IAM bindings for invoker access, add the relevant service accounts to the `invoker_service_accounts` list in your service definition as above.

---

### 9. (Optional) Add to Other Mappings
If your service needs custom values for other mappings (e.g., custom audiences, labels, etc.), add them as needed in the relevant locals.

---

### 10. Apply Terraform
Run `terraform plan` and `terraform apply` to deploy your new service and its IAM bindings.

---

## Summary

- **All service configuration is managed in `locals.tf`.**
- **No changes are needed in `main.tf` for new services.**
- **All IAM bindings are handled automatically if you set `invoker_service_accounts`.**
- **Reuse existing mappings for service accounts, VPC connectors, encryption keys, etc.**

Refer to existing service blocks in `locals.tf` for examples.